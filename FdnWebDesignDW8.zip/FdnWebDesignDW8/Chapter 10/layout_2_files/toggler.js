function swap(targetId){
  
  if (document.getElementById)
        {
        target = document.getElementById(targetId);
        
            if (target.style.display == "none")
                {
                target.style.display = "block";
                } 
            
            else 
                {
                target.style.display = "none";
                }
                
        }
}