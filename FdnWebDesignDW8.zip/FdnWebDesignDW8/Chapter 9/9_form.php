<?php
if ($_POST) {
  if (get_magic_quotes_gpc()) {
    foreach ($_POST as $key => $value) {
      $temp = stripslashes($value);
      $_POST[$key] = $temp;
      }
    }
  $to = 'email_address@your_domain.com';
  $subject = 'Feedback from website';
  // message goes here
$message = "From: " . $_POST['realname'] . "\n";
$message .= "Email: " . $_POST['email'] . "\n";
$message .= "Phone: " . $_POST['phone'] . "\n";
$message .= "Are you a web designer?: " . $_POST['are_you_a_web_designer'] . "\n";
$message .= "What platform do you favor?: " . $_POST['platform'] . "\n";
$message .= "Message: " . $_POST['message'] . "\n";
  // headers go here
$headers = "From: " . $_POST['email'] . "\n";
$headers .= "Reply-To: " . $_POST['email'] . "\n";
$headers .= "Content-type: text/plain; charset=UTF-8";

  $sent = mail($to, $subject, $message, $headers);
  }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<style type="text/css" media="screen">
<!--
@import url("9_form.css");
-->
</style>
</head>

<body>

<?php
if (isset($sent)) {
  echo '<p><strong>Thank you for contacting us. Your message will be responded to as soon as possible.</strong><br /><br /></p>';
  }
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	<fieldset><legend>Personal information</legend><p>
    <label for="realname"><strong>Name</strong></label>
    <br />
    <input name="realname" type="text" class="formField" id="realname" tabindex="11" size="30" />
  </p>
  <p>
    <label for="email"><strong>Email address</strong></label>
    <br />
    <input name="email" type="text" class="formField" id="email" tabindex="21" size="30" />
  </p>
  <p>
    <label for="phone"><strong>Telephone</strong></label>
    <br />
    <input name="phone" type="text" class="formField" id="phone" tabindex="31" size="30" />
  </p>
</fieldset>  <p><strong>Are you a Web designer?</strong><br />
    <label>
    <input type="radio" name="are_you_a_web_designer" value="yes" />
Yes</label>
    | 
    <label>
    <input type="radio" name="are_you_a_web_designer" value="no " />
No</label>
  </p>
  <p>
    <label for="platform"><strong>What platform do you favor?</strong></label>
    <br />
    <select name="platform" tabindex="41" id="platform">
      <option selected="selected">Windows XP</option>
      <option>Windows 2000</option>
      <option>Mac OS X</option>
      <option>Linux</option>
      <option>Other</option>
    </select>
  </p>
  <p>
    <label for="message"><strong>Comments</strong></label>
    <br />
    <textarea name="message" cols="30" rows="5" class="formField" id="message" tabindex="51"></textarea>
  </p>
  <p>
    <input name="Submit" type="submit" class="submitButton" tabindex="61" value="Submit" />
  </p>
</form>
</body>
</html>
